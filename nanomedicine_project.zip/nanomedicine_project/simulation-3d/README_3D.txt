
3D Simulation Folder

Suggested:
- Blender animations
- Three.js particles
- Bloodstream visualization
- DNA holograms
