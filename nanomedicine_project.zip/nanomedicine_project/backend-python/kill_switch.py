
def activate_kill_switch():
    print("Kill switch activated.")
