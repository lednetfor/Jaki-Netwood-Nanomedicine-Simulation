
import random

class Bacteria:
    def __init__(self):
        self.status = "Searching"

    def navigate(self):
        self.status = "Navigating through bloodstream"

    def detect_target(self):
        return random.choice([True, False])

    def release_medicine(self):
        self.status = "Medicine deployed"

    def self_destroy(self):
        self.status = "Self destruction activated"
