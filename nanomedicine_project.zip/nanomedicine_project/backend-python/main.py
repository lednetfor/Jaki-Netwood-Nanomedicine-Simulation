
from bacteria_simulation import Bacteria

bacteria = Bacteria()

for step in range(10):
    bacteria.navigate()

    if bacteria.detect_target():
        bacteria.release_medicine()

    print(f"Step {step}: {bacteria.status}")
