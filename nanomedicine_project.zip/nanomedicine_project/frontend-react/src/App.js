
import React from 'react';

function App() {
  return (
    <div style={{background:'#050b1a', color:'white', height:'100vh', padding:'40px'}}>
      <h1>Nanomedicine Dashboard</h1>
      <p>AI Controlled Biological Simulation</p>

      <div style={{marginTop:'20px'}}>
        <h3>Status:</h3>
        <p>Bacteria Navigation Active</p>
      </div>
    </div>
  );
}

export default App;
